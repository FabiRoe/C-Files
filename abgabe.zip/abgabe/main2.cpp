#include <iostream>
#include <string>
#include "film.cpp"

using namespace std;

void convert(Film* pFilm){
		Film* current = pFilm;
		
		string name;
		cout << " Bitte geben Sie einen Namen an, unter dem die zusammengefügte\n XML-Datei gespeichter werden soll:\n > ";
		cin >> name;
		if (name.size() >= 0){
		fstream pFH (name.c_str(), std::fstream::out);
		while(current->getNext() != NULL){
			if(current->isFirst){
				string temp = current->getXML()+ "\n" + current->getDOCTYPE() + "\n<medien>\n";			
				pFH << temp;
				
			}
			current->convertFilm(&pFH);
			current = current->getNext();
			
		}
		pFH << "</medien>";
		pFH.close();
		cout << "Vorgang abgeschlossen.\n";
		}
		else
			cout << "der Name ist etwas zu kurz\n";
	}

int menu(Film* pFilm){
	char c;
	cout << "\n\n Digitale Videothek: \n > Menü \n > folgende Optionen bestehen: \n > (a)nzeigen \n > (k)onvertieren \n > (s)uchen \n > (e)rweiterte Suche \n >e(x)portieren \n > (v)erlassen \n";
	cout << " > ";
	cin >> c;
	switch(c){
		case 'a':
			pFilm->showAll();
			break;
		case 'k':
			convert(pFilm);
			break;
		case 's':
			char category[255];
			char searchWord[255];
			
			pFilm->resetAll();
			
			cout << "Geben Sie eine Kategorie an, nach der gesucht werden soll: >";
			cin >> category;
			cout << "Wonach soll gesucht werden? >";
			cin >> searchWord;
			if(!pFilm->search(category, searchWord)){
				cout << "Kein Film erfüllt die Suchkriterien \n";
				}
			break;
		case 'e':
		{	
			string category1;
			string category2;
			string searchWord1;
			string searchWord2;
			char Opperator;
			
			pFilm->resetAll();
			
			cout << "Geben Sie die erste Kategorie an, nach der gesucht werden soll:\n > ";
			cin >> category1;
			cout << "Wonach soll gesucht werden?\n > ";
			cin >> searchWord1;
			cout << "\nGeben Sie die zweite Kategorie an, nach der gesucht werden soll:\n (Wenn Sie nur nach dem ersten Kriterium suchen wollen, geben sie x ein) \n > ";
			cin >> category2;
			if(!category2.empty() && category2.length() >= 2){
			cout << "Wonach soll gesucht werden?\n > ";
			cin >> searchWord2;
			cout << "Soll das Objekt beide Kriterien erfüllen? (y/n):\n > ";
			cin >> Opperator;
			switch(Opperator){
				case 'y':
					if(!pFilm->advSearch(category1, searchWord1, category2, searchWord2, 'a')){
						cout << "\nLeider konnte kein Objekt gefunden werden, auf dass dies zutrifft. \n";
						}
					break;
				case 'n':
					if(!pFilm->advSearch(category1, searchWord1, category2, searchWord2, 'o')){
						cout << "\nLeider konnte kein Objekt gefunden werden, auf dass dies zutrifft. \n";
					}
					break;
				default:
					cout << "das geht leider nicht\n";
					break;
							
			}			
			}
			else{
				if(!pFilm->search(category1, searchWord1)){
					cout << "Leider nichts gefunden.\n";
				}
			}
			break;
		}
		case 'v':
			return 0;
			break;
		case 'x':
			pFilm->exportiere();
			break;
		default:
			cout << "Diese Eingabe ist leider nicht zulässig: "<< c;
	}
	return 1;
}

int main(){
	cout << "Herzlich Willkommen in der digitalen Videothek! " << endl;	
	Film* myFilm = new Film();
	myFilm->laden();
	
	//Menu
	while(true){
		if(menu(myFilm) == 0){ 
			break;
		}
	}
	return 0;
}
