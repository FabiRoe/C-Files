#include <iostream>
#include <fstream>
#include <string>
#include <vector>

using namespace std;

class Element{
    public:
        string name;
        string content;
};

class Film{
    private:
    int id;
    char id10;
    char id1;
    vector<Element*> tags;
    string XML;
    string DOCTYPE;
    Film* prev;
    Film* next;
    public:
    int getID(){return id;};
    bool isFirst;
    bool isSearched = false;
    void load(fstream* pFH);
    void loadTXT(fstream* pFH);
    void laden();
    void addElement(Element* pElement);
    void addElement(string pName, string pContent);
    void showFilm();
    void showAll(){Film* current = this; while(current->getNext() != NULL){current->showFilm(); current = current->getNext();}};
    void resetAll(){this->isSearched = false; if(this->getNext() != NULL)this->getNext()->resetAll();};
    Film();
    Film(Film* pPrev);
    void setPrev(Film* pPrev){prev = pPrev;};
    void setNext(Film* pNext){next = pNext;};
    Film* getPrev(){return prev;};
    Film* getNext(){return next;};
    string getXML(){return XML;};
    string getDOCTYPE(){return DOCTYPE;};
    bool search(string pCategory, string pContains);
    bool advSearch(string pCategory1, string pContains1, string pCategory2, string pContains2, char pOpperator);
    void convertFilm(fstream* pFH);
    void exportiere();
    void exportHelper(fstream* pFH);
};

Film::Film(){
    prev = NULL;
    next = NULL;
    isFirst = true;
}

Film::Film(Film* pPrev){
    prev = pPrev;
    next = NULL;
    isFirst = false;
}

void Film::exportHelper(fstream* pFH){
    string test = "<filme xml:id=\"";
    test = test + id10 + id1;
    test = test + "\" >\n";
    for(int i = 0; i < tags.size(); ++i){
        string closingTag = tags.at(i)->name;
        closingTag.insert(1,"/");
        test = test + tags.at(i)->name + tags.at(i)->content + closingTag + "\n";
    }
    test = test + "</filme>\n";
    for(int i = 0; i<test.length(); i++){
        pFH->put(test[i]);
    }
}

void Film::exportiere(){
    char c;
    cout << "Möchten Sie : \n > (1) Alle Objekte in eine XML-Datei exportieren,\n > (2) oder nur die Objekte der letzten Suche?\n";
    cin >> c;
    switch(c){
        case '1':
            {
                string name;
                cout << "Unter welchem Namen, soll die Datei abgespeichert werden?\n >";
                cin >> name;
                if(!name.empty()){
                    fstream FH (name.c_str(),fstream::out);
                    if(this->isFirst){
                        string temp = this->getXML()+ "\n" + this->getDOCTYPE() + "\n<medien>\n";
                        FH << temp;
                    }
                    Film* current = this;
                    while(current->getNext() != NULL){
                        current->exportHelper(&FH);
                        current = current->getNext();
                    }
                    FH << "</medien>";
                    FH.close();
                    cout << "Vorgang abgeschlossen.\n";

                }
                break;
            }
        case '2':
            {
                string name;
                cout << "Unter welchem Namen, soll die Datei abgespeichert werden?\n >";
                cin >> name;
                if(!name.empty()){
                    fstream FH (name.c_str(),fstream::out);
                    if(this->isFirst){
                        string temp = this->getXML()+ "\n" + this->getDOCTYPE() + "\n<medien>\n";
                        FH << temp;
                    }
                    Film* current = this;
                    while(current->getNext() != NULL){
                        if(current->isSearched){
                            current->exportHelper(&FH);
                        }
                        current = current->getNext();
                    }
                    FH << "</medien>";
                    FH.close();
                    cout << "Vorgang abgeschlossen.\n";

                }
                break;
            }
        default:
            {
            cout << "Das verstehe ich nicht. \n";
            }
    }
}

void Film::convertFilm(fstream* pFH){
    string test = "<filme xml:id=\"";
    test = test + id10 + id1;
    test = test + "\" >\n";
    for(int i = 0; i < tags.size(); ++i){
        string closingTag = tags.at(i)->name;
        closingTag.insert(1,"/");
        test = test + tags.at(i)->name + tags.at(i)->content + closingTag + "\n";
    }
    test = test + "</filme>\n";
    for(int i = 0; i<test.length(); i++){
        pFH->put(test[i]);
    }
}

void Film::showFilm(){
    cout << "Der Film hat die ID : " << id << " Speicher: "<< this <<endl;
    for( int i = 0; i < tags.size(); ++i)
    {
        cout << tags.at(i)->name << " : " << tags.at(i)->content << endl ;
    }
    cout << "----------------------------------- \n\n";

}

bool Film::advSearch(string pCategory1, string pContains1, string pCategory2, string pContains2, char pOpperator){
    bool flag = false;
    bool flag1 = false;
    bool flag2 = false;
    for( int i = 0; i < tags.size(); ++i)
    {
        if(tags.at(i)->name.find(pCategory1) != string::npos && tags.at(i)->content.find(pContains1) != string::npos){
            flag1 = true;
        }
        if(tags.at(i)->name.find(pCategory2) != string::npos && tags.at(i)->content.find(pContains2) != string::npos){
            flag2 = true;
        }
    }
    switch(pOpperator){
        case 'a':
            if(flag1 && flag2){
                flag = true;
                this->isSearched = true;
                this->showFilm();
            }
            break;
        case 'o':
            if(flag1 || flag2){
                flag = true;
                this->isSearched = true;
                this->showFilm();
            }
    }
    if(this->next != NULL){
        if(next->advSearch(pCategory1, pContains1, pCategory2, pContains2, pOpperator)){
            flag = true;
        }
    }

    return flag;
}

bool Film::search(string pCategory, string pContains){
    bool flag = false;
    for( int i = 0; i < tags.size(); ++i)
    {
        if(tags.at(i)->name.find(pCategory) != string::npos && tags.at(i)->content.find(pContains) != string::npos){
            this->showFilm();
            this->isSearched = true;
            flag = true;
        }
    }
    if(this->next != NULL){
        if(next->search(pCategory, pContains)){
            flag = true;
        }
    }
    return flag;
}

void Film::addElement(string pName, string pContent){
    Element* temp = new Element();
    temp->name = pName;
    temp->content = pContent;
    tags.push_back(temp);
}

void Film::addElement(Element* pElement){
    tags.push_back(pElement);
}

void Film::load(fstream* pFH){
    if(pFH->is_open()){
        char c;
        while(!(pFH->eof())){
            string tag;
            pFH->get(c);
            if(c == '<'){
                tag = "";
                while(c != '>' && !pFH->eof())
                {
                    tag = tag + c;
                    pFH->get(c);
                }
                tag = tag + '>';

                if(tag.find("?xml") != string::npos){ // speichere XML
                    isFirst = true;
                    XML = tag;
                    tag.clear();
                } // speichere DOCTYPE
                else if(tag.find("!DOCTYPE") != string::npos){
                    DOCTYPE = tag;
                    tag.clear();
                } // schließe kommentare aus
                else if(tag.find("<!--") != string::npos){
                    tag.clear();
                } // wenn filme geschlossen wird, muss ein neuer film folgen.
                else if(tag.compare("</filme>") == 0){
                    Film* temp = new Film(this);
                    setNext(temp);
                    tag.clear();
                    temp->load(pFH);
                }
                else if(tag.find("filme") != string::npos){
                    int i;
                    char c;
                    while(c != '\"'){
                        c = tag[i++];
                    }
                    id10 = tag[i];
                    id1 = tag[i+1];
                    id = (int) (tag[i]-48) *10 + (int) (tag[i+1]-48);
                    tag.clear();
                }
                else if(tag.find("medien") != string::npos){
                    tag.clear();
                }
                else{
                    Element* temp = new Element();
                    temp->name = tag;
                    char c;
                    pFH->get(c);
                    while(c != '<'&& !pFH->eof()){
                        temp->content += c;
                        pFH->get(c);
                    }
                    tags.push_back(temp);
                }
            }
        }
    }
    else
        cout << "Die XML Datei ist nicht offen" << endl;
}

void Film::loadTXT(fstream* pFH){
    if(pFH->is_open()){
    char c;
    int tempID = 0;

    while(!pFH->eof()){
        string content;
        pFH->get(c);
        while(c != '\n' and c != '\EOF'){
            content = content + c;
            pFH->get(c);
        }
        if(content.length() >= 6){
        tempID = (int)(content[0]-48)*10 + (int)(content[1]-48);
        Element* temp = new Element();
        Element* temp1 = new Element();
        temp->name = "<ausgeliehen>";
        temp->content = content[3];
        temp1->name = "<ort>";

        int i = 5;
        while(i<content.length()){
            temp1->content += content[i++];
        }
        Film* current = this;
        while(current != NULL){
            if(current->getID() == tempID){
                current->addElement(temp);
                current->addElement(temp1);
                break;
            }
            else if(current->getNext() != NULL){
                current = current->getNext();
            }
            else{
                cout << "Zu der ID : " << tempID << " gibt es kein Film-Objekt\n";
                current = NULL;
            }
        }
    }
    }
    }
    else
        cout << "Die TXT Datei ist nicht offen" << endl;
}

void Film::laden(){
    string sXML;
    string sTXT;
    fstream XML;
    cout << "Bitte geben Sie den Namen der XML-Datei an:\n (Bitte beachten Sie, dass Sie eventuell den Pfad mit angeben müssen)\n > ";
    cin >> sXML;
    XML.open(sXML.c_str());
    load(&XML);
    XML.close();
    cout << "XML-Datei geladen" << endl;
    fstream TXT;
    cout << "Bitte geben Sie den Namen der TXT-Datei an:\n (Bitte beachten Sie, dass Sie eventuell den Pfad mit angeben müssen)\n > ";
    cin >> sTXT;
    TXT.open(sTXT.c_str());
    loadTXT(&TXT);
    TXT.close();
    cout << "TXT-Datei geladen" << endl;
    cout << "Alles geladen" << endl;
}
